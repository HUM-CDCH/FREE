<!-- FREE:PAGE 1 -->
# OntheTypology of Writing Systems

Liudmila L. Fedorova

Abstract. The paper aims to propose a scheme for classification of writing sys­ tems, based on four binary characteristics of spelling: linear vs. non­linear spelling, integral vs. segmental one, complete vs. reduced, simple vs. differenti­ ated spelling. The main attention is given to the non­linear emblematic writing, namely to Aztec script, which shows the examples of linguistic emblems-the first readable writing signs for place names and proper names. Further develop­ ment of writing explores the techniques of segmentation and differentiation that contribute to the refinement of spelling, yet they go along with a trend to reduced and integrated forms, so we have today the coexistence of emblems­emoticons, Chinese characters and highly differentiated alphabets.

# 1. Introduction. The Problem of Typology of Writing Systems

The aim of the present paper is to demonstrate how the existing typol­ ogy of writing systems can be further refined using additional criteria for classification based on the main capabilities of a writer and a reader to compose and decompose, to integrate and to differentiate.

When speaking about historical scripts, it is necessary to distinguish between, on the one hand, the first attempts of using graphic images and signs and, on the other hand, writing practices that have been de­ veloped, based on systems of signs. This division was firstly established by E. Taylor, who distinguished two stages, corresponding to pictogra­ phy and phonography, the former considered as 'proto­writing', and the latter as 'true writing'.

The proto­writing stage is nevertheless not reduced to pictography alone, and the evolution of writing does not always correspond to the widespread cliché 'from picture to letter'.

Liudmila L. Fedorova 0000-0002-2284-6643 Russian State University for the Humanities, 119421 Russia, Moscow, Obrucheva 28­8­105 E­mail: lfvoux@yandex.ru

Y. Haralambous (Ed.), Grapholinguistics in the 21st Century 2020. Proceedings

Grapholinguistics and Its Applications (ISSN: 2681­8566, e­ISSN: 2534­5192), Vol. 5.

Fluxus Editions, Brest, 2021, pp. 805-824.

https://doi.org/10.36824/2020-graf-fedo

<!-- FREE:PAGE 2 -->
First of all, it should be noted that graphic signs can be used for dif­ ferent purposes and therefore for different functions: magic, social, cog­ nitive, mnemonic, decorative, etc., so that the communicative function (transmission of messages) has been only one among others and obvi­ ously not the first one. The use of graphic (or painted) marks in many cases does not differ substantially from the use of object signs such as amulets, counting tokens, status attributes, etc. Totems and amulets as signs of upper patronage could be objects or also graphic or painted marks (e.g., a handprint on a cave wall), and similarly for signs of so­ cial status, of self­identification (e.g., tattoos), of property (tamgas), of association or 'affiliation', of contract, of authenticity, of war or peace; they could form their own symbolic systems of objects and marks, made of distinct graphic images and 'empty' figures or lines without visible reference. So the variety of possible finalities of graphic signs should be taken into account in the investigation of the beginnings of writing per se. The main distinction of writing signs from other marks is not their form, but their function and the way they are used: for transmission of information, for communication or just for demonstrative purposes.

Therefore writing systems can be regarded as a case of a more wide class of semiotic systems, with their own tasks and ways of functioning.

When writing systems are conceived as linguistic systems, they are defined according to their phonetic values and to their capability of transmitting speech. While signs of most semiotic systems can be only interpreted, signs of linguistic writing systems can be read , they refer to language units.

The first classification of phonographic writing systems was pro­ posed in the 19th century in the works of I. Taylor ('The Alphabet' 1883, cf. Daniels, 1996)), it distinguishes logographic, syllabic and al­ phabetic systems. This division, though rather speculative, remains a convenient scheme and a starting point for more detailed classifications. Further contributions to the study and systematization of writing sys­ tems have been made by J. Friedrich, D. Diringer, C. Loukotka, I.J. Gelb, V.A. Istrin, and others. At present, there are various classifications of writing systems that examine in detail the relationship between writing units and language units. These are works by J. Sampson, J. DeFrancis, W. Bright, R. Sproat, P. Daniels, F. Coulmas, H. Rogers, М. Neef, and others.

To return to the original classification, scholars admit that most writ­ ing systems have a mixed nature; first of all this concerns 'logographic' systems, for usually they include both ideographic and phonographic (mostly syllabic) signs. Ideography deals with the level of notions, which may or may not correspond to definite single words: an ideogram may correspond to a space of synonyms or related nouns, or to a class of words with the same root morpheme. So the first class of writing systems may be called logo­syllabic or morpho­syllabic. Yet the reference of 'logo­' or 'morpho­' items is controversial.

<!-- FREE:PAGE 3 -->
The syllabic class also seems to be heterogeneous. Gelb distinguished 'Aegean' systems as a specific class using signs for open short syllables (Gelb, 1963). These are qualified as being based on moras, so this type was later called moraic . Another subclass includes brahmi, devanagari and other derived systems that use specific operational techniques of vocalization; these were qualified as alphasyllabary (Bright, 2000) or abugida (Daniels, 2009a,b). In the Egyptian hieroglyphic script the sub­ systems of consonant 'alphabet' and 2­/3­consonant characters were re­ garded by Gelb as syllabic, due to the pronunciation practice. This also allowed qualifying some other West Semitic scripts as not consonant alphabets, but as a special type that was later named abjad (Daniels, 2009a,b).

The class of alphabets turned out to be heterogeneous as well. The Korean alphabet with its codification of articulation in parts of charac­ ters was qualified by P. Daniels as a 'featural' alphabet.

So the original classification evolved into something more compli­ cated. Scholars proposed their own classification schemes with regard to different criteria of categorization.

# 2. Classification of Writing Systems by H. Rogers

An important generalization was made by H. Rogers, who took into ac­ count three main dimensions of writing systems: (1) type of phonog­ raphy, (2) amount of morphography, and (3) orthographic depth. It is represented in Scheme 1.

1. The type of phonography is given in the horizontal dimension of the scheme: abjad, alphabetic, abugida, moraic, syllabic.
2. The amount of morphography is given in the vertical dimension); 'it is higher when there are symbols that represent the morphemes' (e.g., < 7 > , < $ > ), or 'when spelling distinguishes morphemes ( < by > , < bye > , < buy > )'.
3. Orthographic depth , which is greater when homophonous allomorphs are spelled similarly ( child-children , sign-signal ); it is denoted by the choice between uppercase and lowercase characters in the scheme.

There are five types of writing systems in this classification. The writing systems of different languages in every type can also be charac­ terized by two gradual properties of spelling.

As can be seen in Scheme 1, some languages are located between classes, such as Sumerian, located between moraic and syllabic writ­ ing, and Pahawh Hmong, located between alphabetic and abugida writ­ ing. Rogers assumes that there is no clear division by class, but rather a continuous space, in which some scripts cannot be clearly assigned to a specific class. This may indicate that they have properties of different classes, or that the criteria for determining them have not been devel­ oped. Rogers argues that this abstract space is a proper representation for the scheme, because many scripts are of mixed nature.

<!-- FREE:PAGE 4 -->
Scheme 1. Rogers' generalized classification (Rogers, 2005, p. 274) (uppercase letters denote deep systems; lowercase letters, shallow ones)

Still there arise some questions about this classification.

Why are moraic systems opposed to abjad and abugida? The nature of basic syllables may be also moraic in these systems for they have ad­ ditional means to designate long vowels in a syllable-by two moras, or by 'weak consonants' as matres lectionis in abjad, or by distinguishing the diacritics for short and long vowels in abugida.

The definition of the amount of morphography presupposes two dif­ ferent cases. Is it always a matter of morphography, when semantic units are given as single signs ( < 7 > , < % > )? Is it more convenient to speak about the amount of ideography, which can be defined by the number of ideograms? Rogers does not use the term of 'ideogram' be­ cause of its ambiguity, he rather refers to 'abstract pictograms'. Indeed, ideograms are usually opposed to pictograms, the former referring to the more elaborated type of writing than pure pictography, but these terms-'pictogram' and 'ideogram'-are not really opposed. While picto ­ gram refers to signans , the pictorial form of a sign, ideo ­gram presupposes its content, 'idea', signatum . So an ideogram can very well take the form of a pictogram, so that the opposition between them vanishes. V.A. Istrin speaks about fraseography in both cases, distinguishing pictograms and abstract symbols (Istrin, 1965). Nevertheless we do not refrain from us­ ing the term of 'ideogram' for a written sign; we use it for a linear sign or for a pictogram, when it refers to an abstract notion on the base of semantic shift. In turn, the term of 'pictogram' is more appropriate for the iconic image in its literal sense (a pictogram < ☼ > can literally de­ note the sun, but as an ideogram it can have meanings such as 'light', 'day' based on a metonymic shift, or the meaning of 'majesty' through a metaphoric shift).

<!-- FREE:PAGE 5 -->
# 3. An Additional Categorization

Let us return to the first classification of writing systems in its widely accepted form, and develop it by adding further divisions. The logic of dividing classes presupposes binary branching on the hierarchical lev­ els. As a result we obtain eleven subclasses, labeled by traditional or mostly representative labels; some subclasses are attested only in a sin­ gle writing system example and therefore are labeled by its name.

Three traditional classes can be distinguished with respect to the type of phonography: morphosyllabic (or logosyllabic), syllabic, and al­ phabetic writing, each one having its own subtypes (subclasses):

- (A) morphosyllabic/logosyllabic writing is mixed, with two types of graphemes: morphemes/words (semantic units) or phonetic seg­ ments of syllabic type:
- nonlinear systems (mixed emblematic type);
- linear systems (mixed linear type).
- (B) Syllabic writing:
- primal syllabic (integral) spelling with graphemes, corre­ sponding to syllables or phonetic segments of syllable types (CVC, CCVC, and CV, CVV, CVCV…; there may be more than one syllable in a grapheme);
- (a) its complete form is represented in many ancient scripts; in the modern lolo writing system, more than 800 graphemes are used to represent all possible syllables (Bradley, 2009);
- (b) its reduced (non­vocalized) form is given in Egyptian hi­ eroglyphic (polyconsonantal) writing;
- moraic kana­type writing, with graphemes denoting indivis­ ible phonetic syllables or segments (CV, V, ­C); examples are Aegean scripts in the ancient world and kana systems in mod­ ern Japanese;
- moraic abugida writing with a standard subsystem of vowel modifications (С V , V); examples are Indian scripts and their derivatives, as well as the Ethiopic script;
- moraic reduced writing, abjad: graphically non­vocalized type, but based on vocalized units in pronunciation, presup­ posing an indefinite vowel in syllables (С х ); examples are West Semitic scripts;

<!-- FREE:PAGE 6 -->
- (C) Alphabetic writing, where the main character/letter, corresponds to a sound/phoneme:
- non­vocalized (reduced) writing, in which only consonants are independent graphemes (consonantic alphabet); modern Ara­ bic;
- linear writing, with vowels and consonants sequentially writ­ ten as equal independent graphemes (linear alphabet, also with possible diacritic differentiation); Greek, Cyrillic, Latin, Ar­ menian, and others;
- nonlinear writing, with vowels and consonants written in in­ verted order (Pahawh Hmong is the only known example);
- featural nonlinear writing with graphemes constructed through elements that differentiate articulation features of phonemes (featural Korean, cf. Daniels, 1996; Lee, 2009).

Morphosyllabic nonlinear systems are the most elementary examples of information recording by means of composition of signs, as linguistic emblems (using rebus spelling). In the Aztec script such records con­ vey only some nominations-usually place names or personal names as readable emblems.

Morphosyllabic linear systems already convey a sequence of read­ ing signs, for words and syllables, although they may allow some viola­ tions of the linear order (for example, the ornamental arrangement of signs in Mayan spelling, or the 'honorifical' order in Egyptian spelling, or graphic blocks in Chinese). This is a general phenomenon, observed in elaborated ancient scripts. The historical morphosyllabic systems usually have a rather representative and stable class of ideograms for semantic units and a more compact class of syllable signs.

Thesyllabic component of morphosyllabic systems can be further an­ alyzed with respect to the organization of pronunciation units (type of phonography). Many syllabic systems have evolved historically out of morphosyllabic in order to get adapted to different languages. Whole­ syllable (integral) spelling is opposed to moraic spelling: the former uses indivisible units while the latter uses decomposed, segmental ones. Moraic systems have their own subclasses: kana, abugida and abjad. We consider abjad as a moraic system for its characters presume vocalized consonants as minimal pronunciation units, naturally used in spelling and reading.

Alphabetic systems can be complete (vocalized) or reduced (conso­ nant). The latter are systems derived from abjad using diacritics for vo­ calization. Their characters are not syllables anymore because vowels have their own representations.

Linear alphabets can be based on simple characters or include char­ acters differentiated by diacritics.

'Non­linear alphabets' are those in which the order of graphemes within a syllable is violated (while the order of syllables is linear; so they use both linear and non­linear order): this is the case of the Pahawh script where graphemes in a syllable are displayed in reverse order, and in Korean syllable blocks. These types have unique representations. This classification is displayed in Scheme 2.

<!-- FREE:PAGE 7 -->
Scheme 2. The revised classification

As a result we have three main classes (morphosyllabıc, syllabıc, alphabetıc) and their subclasses (emblematic, lınear morphosyl­ labic, lolo, egyptıan, kana, abugıda, abjad, alphabet, consonant alphabet, and also two unique 'non­linear Alphabets'-pahawh and featural korean. It should be taken into account that morphosyl­ labic types can be qualified as mixed systems with syllabic components (e.g., Linear B can be qualified as a morphosyllabic writing system with a kana­type syllabic component).

It can be seen that the categorization is based on four binary charac­ teristics of spelling:

1. linear/nonlinear spelling : ex. g.: < 1 ­ 2 ­ 3 ­ 4 > vs. < 2 2 ­ x 3 > ;
2. integral (whole­syllable)/segmental (moraic) spelling: [CCVC], [CVCVC] vs. [CV]­[CV]­[CV];
3. complete (vocalized)/reduced (consonantic) spelling: [CV] vs. [C x ];
4. simple/differentiated spelling: [CV] vs. [C v ].

These binary oppositions can operate at different levels of analysis that allow more detailed classification.

Let us examine them more carefully.

<!-- FREE:PAGE 8 -->
# 3.1. Linear vs. Nonlinear Spelling

Linearity is the first significant dimension of classification. Linear arrangement is an important step in the formation of phonetic writ­ ing. It follows the deployment of speech in time using one graphic dimension-on a line, be it horizontal or vertical. It is opposed to a non­linear, emblematic layout of readable graphic units which appears at the first stage of logo­/morpho­syllabic writing. Emblematic writ­ ing is in turn opposed to pictography and ideography where glyphs are non­readable signs and images, and just interpreted symbols. Linguistic (readable) emblems first appear in a pictographic frame representation for rendering names and numbers that correspond to words. While we have a single sign, the fact whether it represents a notion or a concrete word is ambiguous, be it an ideogram or a logogram. Only names can be phonetically reconstructed, and only in the case when they are rep­ resented as composition of signs with rebus spelling.

Yet readable emblems usually have reduced representations, for they allow only partial reading, using rebus spelling and omitting some el­ ements. Their use can be observed in the Aztec codices that combine pictographic and phonographic techniques.

# 3.1.1. Aztec Emblems in the Space of Pictorial Text

The term 'emblem' was firstly introduced in the investigation of writing systems by H. Berlin (1958, pp. 111-119), yet not in the linguistic sense. It was used for signs designating Maya place names, which Berlin pre­ supposed to be not readable, but only requiring interpretation. Place names got their readings in the decipherment of Maya script by Ju. V. Knorozov. In Aztec manuscripts, place­name emblems are also readable signs, though they have pictorial form and are used in a pictographic context, where events are represented by iconic images. The term of 'emblematic writing' has been introduced in Fedorova (2009), along with the notion of linguistic emblem .

The use of linguistic emblems can be illustrated by examples from Codex Mendoza, an Aztec manuscript, written in 1547, edited and com­ mented by F. Berdan (Berdan 1997). My analysis is based on the Berdan's comments, on the Nahuatl Grammar by T. Sullivan (1983) and Nahuatl Dictionary by Rémi Siméon (1857) edited online 1 by Alex Wim­ mer. Its first part is a chronicle.

The beginning of Codex Mendoza (Fig. 1a) is consecrated to the foundation of Tenochtitlan. It uses the stable arrangement of pictorial glyphs: the central symbol indicates the main subject of the narrative event, the surrounding glyphs designate its participants, and the mar­ ginal frame serves for calendar emblems. The standard frame represen­ tation can convey information that may correspond to text; we may use the term ' textogram ' for it, following I. M. Dyakonov (1976, p. 570). Only some emblems can be read.


<footnote>1. Bodleian Library, Oxford UK, https://digital.bodleian.ox.ac.uk/objects/ 2fea788e-2aa2-4f08-b6d9-648c00486220</footnote>


<!-- FREE:PAGE 9 -->
Fıgure 1. (a) Foundation of Tenochtitlan (Codex Mendoza, 2 r , fragment). (b) The conquests of Lord Itzcoatl (Codex Mendoza, 5 v )

The central image is an emblem of Tenochtitlan, it is composed of three glyphs: a stone ( te­tl ), a cactus ( noch­tli ) on it (absolutive suffixes ­tl , ­tli , ­li do not participate in compounding), and an eagle in the middle of the cactus to convey the sense 'among' (­ titlan ). The whole composi­ tion is based on another emblem: a shield with arrows, as a symbol of war; it indicates the conquest of the territory. The symbolic emblem of war is not readable (it is understood without reading), though there is a stable binomial expression in Nahuatl, mitl chimalli 'arrows, shield', which could correspond to it. So two root components of Te­noch­titlan can be read, and the locative suffix can be reconstructed. We do not know whether the etymology of the name should be understood as 'a place of cactus among stones'; more probably it refers to the name of a founder of Tenochtitlan, Tenoch, and should be read 'among the people of Tenoch'. The scribe may also be using a visual image that has a readable parallel as a rebus, so we can consider it as a linguistic emblem. The role of the eagle is not only semantic, but primarily symbolic, for according to a prophecy by wise men, the city was to be founded at the place where an eagle would sit. So the scribe used iconic images with phonetic and symbolic values.

<!-- FREE:PAGE 10 -->
Other readable emblems are the Lords' names that are attached to the pictorial glyphs-standard images of Lords.

Another textogram example can be seen in Fig. 1b. It is dedicated to the conquests of Lord Itzcoatl. Lord Izcoatl ('snake with arrows' coa­ tl 'snake', iz­tli 'arrow'), a name­emblem attached to his head, 'speaks' (a blue scroll as a sign of speech) about his war conquests (emblem of war-the shield and arrows), which are given in the emblems of a 'con­ quered city'-a burning and falling temple. Each city­emblem has an attachment that renders its name: the name's emblem. The whole can be interpreted: Izcoatl speaks: I have conquered these cities… It should be noted that the word for Lord tlahtoani literally means 'speaking' in Nahuatl, so the scroll may serve as a status indication.

# 3.1.2. Examples of Linguistic Emblems in Nahuatl

The arrangement of readable name­emblems is non­linear, it is a com­ position of images that can represent an imaginary scene. Here are some examples.

The emblem of CUAUH­NAUAC resembling to a 'speaking tree' (Fig. 2a) represents сuahu­itl 'tree' + nahua­tl 'speech', homophone of loca­ tive suffix nahuac 'near'; the resulting meaning is 'near trees'.

The emblem of AHUACA­TLAN 'tree with teeth' (Fig. 2b) stands for ahuaca­tl 'avocado' + tlan­tli 'teeth', homophone of locative suffix tlan 'where there is a lot of…', 'among…' to express the sense of 'the place, where there is a lot of avocado trees' (tree and avocado use similar glyphs, but a reader could recognize compound names). Both cases are examples of rebus substitution.

Figures 2c and d show another way of phonetic representation, using phonetic complementation, a hint given by rebus reduplication. There we have two versions of the same place­name emblem of CUA­HUAH­ CAN: cuāuh­tli 'eagle' reduplicated by сuahu­itl 'tree' (Fig. 2c), or: cua­itl 'head' of cuāuh­tli 'eagle' (in one graphic image) reduplicated by сuahu­ itl 'tree' (Fig. 2d); the next two components have no visual expression: huah (possessive suffix) + can (locative suffix); the whole designates 'the place of owners of eagles', or 'the place of eagles'. Fig. 2c shows the name­emblem attached to the symbol of burning temple that means 'conquered city', Fig. 2d represents the same name bound to the glyph hıll ( tepe­tl ) for 'city, settlement' ( altepe­tl ). Symbols of burnıng tem­ ple and hıll are just pictorial images, they serve as a base for linguistic emblems.

Place­name emblems usually are attached to emblems of cities or burning temples, but they can also be used independently, designating tribes or settlements in the lists of tributes.

<!-- FREE:PAGE 11 -->
Fıgure 2. (a) CUAUHNAUAC; (b) AHUACATLAN; (c) (conquered city of) CUAHUAHCAN (quaguacan); (d) (city of) CUAHUAHCAN; (e) COYUCAN; (f)ACATEPEC; (g) COYUCAC; (h) ACAMAPICHTLI

Fig. 2e, COYU­CAN, 'the place of (lean) coyotes' (or COYU­HUAH­ CAN 'the place of owners of coyotes'), shows another example of pho­ netic complementation: coyo­tl 'coyote' with a round hole coyoc­tli 'hole' or coyoc­tic 'hole ridden'; the phonetic hint confirms the meaning 'coyote' (not 'dog'). The locative suffix can has no visual expression.

Fig. 2f, ACA­TEPE­C, with the morphemic structure: aca­tl 'reed' + tepe­tl 'hill' + c (locative suffix) 'on the hill of reeds', seems to be a direct iconic image of the name. Yet it uses a special semantic hint to confirm its reading. Its visual representation includes three components: hill ( tepetl ), reed ( acatl ) and dart ( acatl ). The glyph of hill is readable and serves also as a graphic base for other symbols. The new phonetic device is the semantic reduplication for acatl : it is given in two images: grass and a dart, corresponding to the meaning of acatl , and knowing that a dart is made using a reed's stem. It serves to recognize the image of reed that otherwise could be understood as plain grass or an arbitrary plant. The locative suffix has no visual representation, though its meaning can be implicitly assumed from the arrangement of two small glyphs on the top of the big one (hıll).

<!-- FREE:PAGE 12 -->
Figs. 2g and h represent the names of the tribe COYU­CAC and of Lord ACA­MAPICH­TLI. These names are attached to images of per­ sons. The name COYU­CAC is divided in parts in order to provide a rebus representation: coyo­tl 'coyote'+ cac­tli 'sandal'; this is a decom­ posed rebus spelling (under the hypothesis of a rebus substitution for both parts of the word). The Lord's name probably represents its con­ tent in graphic images: aca­tl 'dart' and mapich­tli 'hand, fist' that means 'a fist holding darts'. It seems like a rather iconic representation, yet for the native readers these images refer to concrete words for 'fist' (not arm) and 'darts'. In fact, in this name, two principles of writing coexist: ideographic, presupposing reference to a notion, and phonographic, re­ ferring to a word. We may be confident in the phonographic nature of this sign, since it is confirmed by rebus spelling; yet we may suggest that images in name­emblems were recognized by native users in their exact phonetic form, as words, because the combination of glyphs increases the chance of guessing their fixed phonetic forms corresponding to a name.

Thecomplexity and ingenuity of Aztec script consist in the decompo­ sition of whole names and in the use of the same glyphs for pictographic and phonographic functions.

# 3.1.3. Graphic Arrangement of an Emblem

The previous examples show that an Aztec linguistic emblem usually consists of two (or three) meaningful graphic components, which are sufficient for the reconstruction of the whole name.

The arrangement of readable components relies on a decision taken by the scribe. Locative suffixes can be transferred by mutual disposition of components, as in Tenochtıtlan and Acatepec. The whole com­ position can be done in different ways: by syncretism or reduplication, incompletely or by reduplication.

Fıgure 3. (a) MATLATLAN (Codex Mendoza). (b) MATLATLAN (Historia Tolteca Chichimeca). (c) YACAPICHTLAN (Codex Mendoza)

<!-- FREE:PAGE 13 -->
Thus, the place­name 'Matla­tlan' ('net' + 'where there is a lot of…' or 'in') is given differently in the two codices: in juxtaposition of a net matlatl and teeth tlantli (Fig. 3a) or as a hill tepetl (non­readable base) in a net.

The place­name 'Yacapich­tlan' ( yacapitz(­ahuac/­actic) 'pointed' + tlan 'where there is a lot of…', together: 'the place of many pointed things') is represented as a hill with a nose, yaca­tl (for 'pointed') and an insect, bug petz(o­tli) which can bite it; the scribe's witty invention.

The logical incompatibility of images or, in the contrary, their fantas­ tic combination into an entire image, and the incompleteness of spelling are characteristic of the graphic display of a linguistic emblem. They presuppose 'the intuition of meaning' or 'feeling of meaning', which J. Elkins qualifies as nesessary for understanding any sort of emblem (Elkins, 2003).

It follows that the main writing techniques in Aztec emblems con­ sist in rebus substitution, rebus phonetic complementation (phonetic reduplication), decomposed rebus spelling, and semantic reduplication (semantic­phonetic analogy), when the scribe provides two parallel im­ ages corresponding to different meanings of a polysemic word (not homonyms). The scribe may combine direct iconicity and language game, phonetic analogy and semantic hint in a composition that cor­ responds to a compound word.

Thus we can define a linguistic emblem as a readable complex sign with a linguistic referent. Its main properties are the function of nomi­ nation (usually proper names and place names), non­linear arrangement of components, their limited number (usually 2­3), a new meaning of the whole that is not just a sum of meanings of its components, and therefore the possible incompleteness of spelling. For, as W. von Humboldt noted, synthesis creates an entity that is not contained in any of the combining parts. Emblems can represent signs of language, nominations, but not speech, for they are not able to convey the strict syntactic arrangements that are necessary for sentences.

# 3.1.4. Emblems in Early Egyptian Script

Wepresuppose that emblematic type of writing was proper to many an­ cient systems at the very beginning of writing. The use of emblems can be seen, for example, in early Egyptian hieroglyphic inscriptions (Fig. 4), such as the Narmer Palette and the Scorpion Mace Head (both 32nd-31st c. BC), events are narrated through iconographic pictures while names are rendered phonetically. The name NARMER (Fig. 4a) (presumably for king Menes) nʿr­mr 'painful, stinging', or 'fierce catfish' is rendered as a combination of two glyphs. It is given three times: be­ tween the heads of cows (goddess Hathor) and near the king's head in the upper sector of the palette. There are other examples of small glyphs near the people's heads, they should be their names. There is also a 'number emblem' above the captive's head: 6 lotus flowers designate 6,000 captive warriors. The name of 'Scorpion' (Fig. 4b) is given in two images in front of the king's head.

<!-- FREE:PAGE 14 -->
Fıgure 4. (a) The Narmer Palette (32nd-31st c. BC). (b) The Scorpion mace head (32nd-31st c. BC)

Examples of emblematic writing show that the formation of a lin­ guistic emblem occurs at the very initial stages of writing, contributing to the allocation of simple pictorial components and their stabilization in the phonetic function.

# 3.1.5. Emblematic Techniques in Linear Scripts

The formation of linear writing is a gradual process, and it involves not only a fixed order of characters, but also the stabilization of their po­ sition and orientation on the line. In early examples of 'linear writing' (that is writing on a line, be it horizontal or vertical or something else), the sign can be rotated in different directions, i.e., it still exists as a pic­ torial image and not a written one. It acquires stable orientation when the line obtains a fixed one­dimensional orientation in the writing space.

Stable linear writing can also use the second dimension as additional space, combining linear elements in blocks or adding meaningful marks. This can be seen in hieroglyphic blocks of Mayan, Chinese, or Egypt­ ian hieroglyphic, using the techniques of duplication and triplication of characters or combination of different characters in blocks-not only in their juxtapositions, but also including one in another; this is also attested in the Sumerian cuneiform system. It is also represented in abugida writing systems where the space around the invariant character (akshara) allows the use of diacritics: superscripts, subsripts, post­ scripts, prescripts, and even combinations of positions.

<!-- FREE:PAGE 15 -->
These positions can be used not only for vowel diacritics, but also for ligatures, subscript consonants, as well for pronunciation marks (such as nasalization). In Fig. 5a,b we can see an example: the well­known mantra 'Ō m ma­ni pa­dme hū m ' in six syllable aksharas, in Devanagari and Tibetan scripts:

Fıgure 5. (a) Devanagari. (b) Tibetan. (c) Korean

The emblematic feature of 'new meaning creation' is proper to aksha­ ras with vowel diacritics that acquire a new pronunciation status, which is not the sum of its components (/na/ + /i/ = /ni/, but not /nai/), and to ligatures: (/da/ + /ma/)+ /e/ = /dme/).

Block writing is also characteristic of Korean, where characters form syllable blocks that follow each other in linear order as in abugidas. In Fig. 5c we can see the same mantra written in the form of six Korean blocks.

The layout of characters in blocks allows the reading of components in a well­defined order; the enigmatic nature of emblem can be per­ ceived only through distorted visual proportions of elements that make reading difficult to non­accustomed readers.

In many alphabetic systems, diacritic marks serve for differentiation of pronunciation.

Thus, in alphabets the characters with diacritics can acquire some properties of linguistic emblems: complex structure and new sound meaning.

It should be noted that the ligatured spellings can provide new char­ acters which are then conceived as simple (not complex) signs. Among the examples we have < & > = Latin 'et', < ? > that originates from the ver­ tical arrangement of abbreviation 'qo' of the Latin word 'quæstio,' < ! > from Latin 'Io,' interjection of joy. But their emblematic nature goes forth in their special reference, in opposition with the surrounding con­ text.

# 3.2. Integral vs. Segmental Spelling

This dimension deals with the division of pronunciation units into parts in order to obtain a graphic representation. The starting point is the word as an independent unit of speech. It may be rendered by an iconic pictogram, or by a pictogram of a homonym as a whole or by parts. This is a way to obtain a rebus representation and mixed phonetic spelling (like in Aztec emblems), as well as stable syllabic spelling.

<!-- FREE:PAGE 16 -->
A word (W) may be segmented differently, for example:

```
W=/CCVC/ = [CV]­[CVC] or [CV]­[CV]­[CV] or [CV]­[CV]­[VC], … W=/CVCVC/ = [CV]­[CV]­[CV] or [CV]­[CVC], …
```

Natural segmentation gives a sequence of mora signs.

So we can have two types of spelling:

1. using signs for close (and open) syllables (CVC, CCVC, CVCC, …)lolo­type ( syllabic )
2. using signs only for moras (CV, V, ­C) as minimal pronunciation units in decomposing a word-kana­type ( moraic ).

It is argued that not only Japanese refers to moraic systems, but also abugida and abjad refer to the same segmental class, since they have secondary ways for conveying long vowels into the syllable.

The decomposition trend seems to be opposite to the one of em­ blematic combination; yet it arises from the emblematic representation of complex units and contributes to the development of phonographic writing without support of meaningful units. Both trends coexist in an­ cient scripts.

# 3.3. Complete vs. Reduced Spelling: Abugida and Abjad

Abugida with a standard subsystem of vowel modifications (С V , V) is an example of complete vocalized writing: different vowels have different representations as independent signs or inside syllables.

Abjad is a graphically reduced, non­vocalized type, presupposing an indefinite vowel in a syllable (С х ), since a consonant cannot form a sylla­ ble per se, as pronunciation unit. The inherent vowel must be inferred from the context. So while abjad characters do not form 'emblems' as such, written words may have the property of only partial sound repre­ sentation that requires the 'feeling of meaning' as do emblems.

Reduced spelling is proper to Egyptian hieroglyphic writing with uniliterals С х , biliterals С х С х or triliterals С х С х С х .

Reduced systems are also consonantic alphabets, where vowels have stable diacritic forms (not always used).

In all these non­vocalized systems, a vowel is conceived as the inher­ ent characteristic of a syllable (mora), is variable in word formation and cannot begin a syllable.

Examples of reduced spelling of another nature can be also found in Aztec emblems, where the locative suffixes of place names are often omitted. The logographic dongba script is reduced, due to the absence of grammatical indexes; a similar case is probably the one of the rongorongo script of Easter Island (not yet deciphered).

<!-- FREE:PAGE 17 -->
Both trends serve to support the interests of users: complete spelling serves to readers, and reduced spelling, to writers.

# 3.4. Simple vs. Differentiated Spelling

Differentiation is an important device in the development of writing. It includes different techniques. Semantic differentiation appears in the use of graphic determiners in ancient writing systems. These are pic­ tograms with classifying function, so they are hyperonyms to the de­ termined units and serve to differentiate homonyms. Another sort of semantic differentiation in logographic writing, given by H. Rogers, is the use of additional minor graphic signs for specialization of meaning; it occurs in Sumerian writing, when small cuneiform strokes are drawn inside the logogram HEAD as indication for teeth, in order to express the meaning of 'mouth' (Rogers, 2005, pp. 88-89).

Phonetic differentiation presupposes the use of elements that refine the reading of a simple sign; it works already on the morphosyllabic level (as phonetic complementation), for example in Egyptian script:

$$

$$

Abugida differs from kana systems using diacritic vowel modifications of the invariant sign, whereas kana uses several invariant signs for different vocalization (Fig. 7b). Yet kana differentiates diacritics for voiced and unvoiced pairs (Fig. 7c)

Fıgure 6. (a) Devanagari. (b) Japanese kana

Alphabetic writing is the last stage of phonological analysis.

According to alphabetic principle, every phoneme, consonant or vowel must be represented by a full­formed grapheme.

Abjad writing is largely defined by the phonological, morphological, and lexical structure of classical West Semitic languages, where a vowel is not an independent unit: it cannot start a syllable, and it is a word­ formation variable (and not a constant attribute of the root).

<!-- FREE:PAGE 18 -->
Alphabetic writing appears in languages in which vowels have inde­ pendent values, so that they are represented by characters equivalent in size and position to consonant letters.

We can allow the metaphor of democracy here (with 'gender' sense): vowels are hidden under yashmak in the presence of consonants in ab­ jad, they form different 'garments' for consonants in abugida (some­ times they form the 'soul' of a consonant 'body' in an akshara), and, fi­ nally, the Greek claim for democracy gives them their independent sta­ tus in alphabetic text.

# 4. Some Concluding Comments

Thus, the main points made in this work concern:

1. the role of linguistic emblems in the formation of phonographic writing;
2. the representation of the evolution of writing based on the psycho­ logically distinguishable units of speech and language, which are fixed in written signs: the word as a semantic and phonetic unit and the syllable (mora) as a pure pronunciation unit;
3. the alleged moraic nature of abjad and abugida writing;
4. the use of binary classification features (linear/nonlinear, inte­ gral/decomposed, complete/reduced, simple/differentiated spel­ ling) for developed typological schemes of writing systems.

Thanks to the four characteristics of writing systems mentioned above, we can describe transfers from one type to another. Thus, ab­ jad differentiated by diacritics becomes a consonant­alphabet. Alpha­ bets using techniques of non­linear block spelling may be designated as a separate type. The next step of differentiation deals with featural Korean script.

The proposed scheme can be further detailed; some additional classi­ fication criteria, taking part in the way a writing system is functioning, can be identified as follows:

- -amount of ideography (not only of morphography),
- -amount of xenography (taking into account the use of graphemes of foreign, different languages, xenograms, or heterograms),
- -level of graphic complexity (analytic/synthetic writing, the latter presupposing the use of complex graphemes, cf. Fedorova, 2012),
- -orthographic depth (according to Rodgers),
- -level of semiotic heterogeneity (with respect not only to different languages, but also to graphic systems of different semiotic nature, cf. Perri, 2014).

<!-- FREE:PAGE 19 -->
These dimensions of writing need special investigation. Only a few comments can be made. Thus, modern devices allow using different sorts of icons along with written words; this is a case of mixed writing. The use of emoticons becomes common for informal communication all over the world, for they give expressive images of emotions, as in these Japanese examples:

$$

$$

Another case of mixed writing happens in the simultaneous use of Latin and Cyrillic (or another national) writing signs; it is often a result of contacts of languages and of their writing systems (ibid.).

Let us also mention a particular language game, using number codes. This method occurs widely in advertisements and informal Internet communication. Here are examples of this kind of 'numeric codifica­ tion,' in Chinese phrases:

```
886 /bā bā liù/ = 拜拜了 /bàibài le/ 'Bye­bye' 768 /qī liù bā/ = 吃了吧 /chī le ba/ 'Let's go eat'!
```

Multilingual and multiscript texts on bill­boards are common prac­ tice in modern cities, forming their linguistic landscape.

The contrast between the writer's and the reader's interest, con­ tribute to the development of writing. It may not be so much about evolution as about writing improvement. Different forms of writing co­ exist in the modern world, addressing different needs: speed, exactness of speech transfer, the best visual presentation of content or just of its form… Writing can serve not only for distributing information, but also to conceal it; it can be a means of magic, or play, of expressiveness, or of decoration. But all of these mixed forms and techniques can exist only as deviations of existing standard writing systems or as graphic games taking advantage of the creative potential of the art of writing.

# References

- Berdan, Frances F. (1997). 'The Place­Name, Personal Name, and Title Glyphs of the Codex Mendoza: Translations and Comments.' In: The Essential Codex Mendoza . Ed. by Berdan Frances F. and Patricia Rieff

Anawalt. Vol. 1. Berkeley: University of California Press, pp. 163-239.

- Berdan, Frances F. and Patricia Rieff Anawalt (1997). 'Glyphic Conven­ tions of the Codex Mendoza.' In: The Essential Codex Mendoza . Vol. 1. Berkeley: University of California Press, pp. 93-102.
- Berlin, Heinrich (1958). 'El glifo 'emblema' en las inscripciones mayas.' In: Journal de la Société des Americanistes 47, pp. 111-119.

<!-- FREE:PAGE 20 -->
- Bradley, David (2009). 'Language policy for China's minotities: Orthg­ raphy development for the Yi.' In: Written Language & Literacy 12.2, pp. 170-187.
- Bright, William (2000). 'A matter of typology: Alphasyllabaries and Abugidas.' In: Study in the Linguistic Sciences 30.1, pp. 63-71.
- Daniels, Peter T. (2009a). 'The study of writing systems.' In: The World's Writing Systems . Ed. by P. Daniels and W. Bright. New York: Oxford University Press, pp. 3-17.
- (2009b). 'Two notes on terminology.' In: Written Language & Literacy 12.2, pp. 258-274.
- Dyakonov, Igor M. [Дьяконов, Игорь М.] (1976). 'Протошумерские иероглифы [Proto­Sumerian hieroglyphs].' In: Тайны древних пись­ мен: Проблемы дешифровки [The mysteries of ancient scripts: Problems of de­ ciphering] . Ed. by Igor M. Dyakonov [Игорь М. Дьяконов]. Москва [Moscow]: Прогресс [Progress], pp. 569-571.
- Elkins, James (2003). 'Four ways of measuring the distance between alchemy and contemporary art.' In: HYLE-International Journal in Phi­ losophy and Chemistry 9, pp. 105-118.
- Fedorova, Liudmila (2009). 'The Emblematic Script of the Aztec Codices as a Particular Semiotic Type of Writing System.' In: Written Language & Literacy 12.2, pp. 258-274.
- (2012). 'The development of structural characteristics of Brahmi script in derivative writing systems.' In: Written Language & Literacy 15.1, pp. 1-25.
- Gelb, Ignace J. (1963). A study of Writing . Chicago: Chicago University Press.
- Istrin, Viktor A. [Истрин, Виктор А.] (1965). Возникновение и развитие письма [The appearance and development of writing] . Москва [Moscow]: Наука [Nauka].
- Lee, Sang­Oak (2009). 'The Korean alphabet: An optimal featural sys­ tem with graphical ingenuity.' In: Written Language & Literacy 12.2, pp. 202-212.
- Perri, Antonio (2014). 'Why writing is not (only) transcribing? Writing codes in contact: steps towards multigraphic literacy practices.' In: Testo e Senso 15, pp. 75-98.
- Rogers, Henry (2005). Writing systems: A linguistic approach . Malden, MA and Oxford, UK: Blackwell Publishing.
- Siméon, Rémi (1963). Dictionnaire de la langue nahuatl ou mexicaine . Ed. by Alex Wimmer. Graz, Austria: Akademische Druck­ u. Verlagsanstalt.
- Sullivan, Thelma D. (1983). Compendio de la Gramática Nahuátl . México: Universidad National Autónoma de México.